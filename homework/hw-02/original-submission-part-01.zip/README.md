# Assignment 2

I completed the analytical solutions and computational work included in `submission/`. The course-provided problem statement is `statement.pdf`.

I retain the original submitted filenames and relative paths inside the submission. Reports, MATLAB scripts, Simulink models, figures, and supplied data are included where available. These are archived coursework submissions; inclusion does not imply that every numerical result has been independently reproduced.
